from flask import Flask
from app.routes import *

app = Flask(__name__)